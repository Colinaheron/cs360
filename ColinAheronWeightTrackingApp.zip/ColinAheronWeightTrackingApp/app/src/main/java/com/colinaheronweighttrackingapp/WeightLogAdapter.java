package com.colinaheronweighttrackingapp;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class WeightLogAdapter extends BaseAdapter {

    private Context mContext;
    private ArrayList<String> mWeightEntries; // List of weight entries

    public WeightLogAdapter(Context context, ArrayList<String> weightEntries) {
        mContext = context;
        mWeightEntries = weightEntries;
    }

    @Override
    public int getCount() {
        return mWeightEntries.size();
    }

    @Override
    public Object getItem(int position) {
        return mWeightEntries.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            // Inflate the grid item layout if it's not already created
            LayoutInflater inflater = LayoutInflater.from(mContext);
            convertView = inflater.inflate(R.layout.grid_item_weight, parent, false);

            // Create a ViewHolder to hold references to the views within the layout
            holder = new ViewHolder();
            holder.textViewWeightEntry = convertView.findViewById(R.id.textViewWeight);
            holder.buttonDeleteEntry = convertView.findViewById(R.id.buttonDelete);

            convertView.setTag(holder);
        } else {
            // If convertView is already created, reuse it and retrieve ViewHolder
            holder = (ViewHolder) convertView.getTag();
        }

        // Bind data to views
        String weightEntry = mWeightEntries.get(position);
        holder.textViewWeightEntry.setText(weightEntry);

        // Handle delete button click
        holder.buttonDeleteEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perform actions to delete the entry at the given position
                // For example, you might remove the entry from the dataset and notify the adapter
                mWeightEntries.remove(position);
                notifyDataSetChanged();
            }
        });

        return convertView;
    }

    // ViewHolder pattern to improve ListView performance by recycling views
    private static class ViewHolder {
        TextView textViewWeightEntry;
        Button buttonDeleteEntry;
    }
}

