package com.colinaheronweighttrackingapp;

import android.content.SharedPreferences;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;

public class LoginActivity extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPassword;

    private static final String PREFS_NAME = "MyPrefs";
    private static final String PHONE_NUMBER_KEY = "phoneNumber";

    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Initialize EditText fields
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);

        // Login button click listener
        Button buttonLogin = findViewById(R.id.buttonLogin);
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle login
                loginUser();
            }
        });

        // Create Account button click listener
        Button buttonCreateAccount = findViewById(R.id.buttonRegister);
        buttonCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle creating a new account
                createAccount();
            }
        });
    }

    private void showNotificationPopup() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("SMS Notifications");
        builder.setMessage("Do you want to enable SMS notifications?");
        builder.setPositiveButton("Enable", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Handle enabling SMS notifications
                // You can implement the logic to enable SMS notifications here
                dialog.dismiss();
                showPhoneNumberPopup();
            }
        });
        builder.setNegativeButton("Disable", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Handle disabling SMS notifications
                // You can implement the logic to disable SMS notifications here
                dialog.dismiss();
                Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
                startActivity(intent);
                finish(); // Optional: Finish the LoginActivity to prevent going back
            }
        });
        builder.setCancelable(true); // enable dismissing dialog by clicking outside
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void showPhoneNumberPopup() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter Phone Number");
        final EditText input = new EditText(this);
        input.setHint("Phone Number");
        builder.setView(input);
        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Handle saving phone number
                String phoneNumber = input.getText().toString();
                savePhoneNumber(phoneNumber);
                Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
                startActivity(intent);
                finish(); // Optional: Finish the LoginActivity to prevent going back
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void loginUser() {
        String username = editTextUsername.getText().toString();
        String password = editTextPassword.getText().toString();

        // Check if username and password are not empty
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(LoginActivity.this, "Please enter username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Initialize LoginDBHelper instance
        LoginDBHelper dbHelper = new LoginDBHelper(LoginActivity.this);

        // Check if the username exists in the database
        if (!dbHelper.checkUsernameExists(username)) {
            Toast.makeText(LoginActivity.this, "Username does not exist.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if the entered password matches the password associated with the username
        boolean isAuthenticated = dbHelper.checkLogin(username, password);

        if (isAuthenticated) {
            // Authentication successful, navigate to DashboardActivity
            showNotificationPopup();
        } else {
            // Authentication failed, display an error message
            Toast.makeText(LoginActivity.this, "Incorrect password. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }

    private void createAccount() {
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString();

        // Check if username and password are not empty
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(LoginActivity.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Initialize LoginDBHelper instance
        LoginDBHelper dbHelper = new LoginDBHelper(LoginActivity.this);

        // Check if the account already exists
        if (dbHelper.checkUsernameExists(username)) {
            Toast.makeText(LoginActivity.this, "Account already exists", Toast.LENGTH_SHORT).show();
            return;
        }

        // Account does not exist, create new account
        dbHelper.addUser(username, password);

        // Display success message
        Toast.makeText(LoginActivity.this, "Account created successfully", Toast.LENGTH_SHORT).show();
    }

    private void savePhoneNumber(String phoneNumber) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(PHONE_NUMBER_KEY, phoneNumber);
        editor.apply();
    }

}
