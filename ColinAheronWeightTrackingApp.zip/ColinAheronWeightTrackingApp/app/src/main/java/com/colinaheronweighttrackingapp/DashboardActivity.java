package com.colinaheronweighttrackingapp;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.content.SharedPreferences;

public class DashboardActivity extends AppCompatActivity {

    private WeightDataSource dataSource;
    private WeightGridAdapter adapter;
    private EditText editTextDate;
    private EditText editTextWeight;

    private static final int SMS_PERMISSION_REQUEST_CODE = 101;
    private EditText editTextGoalWeight;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize data source
        dataSource = new WeightDataSource(this);
        dataSource.open();

        // Initialize GridView
        GridView gridView = findViewById(R.id.gridView);
        Cursor cursor = dataSource.getAllWeightEntries();
        adapter = new WeightGridAdapter(this, cursor, dataSource);
        gridView.setAdapter(adapter);

        // Initialize EditText fields for adding new entries
        editTextDate = findViewById(R.id.editTextDate);
        editTextWeight = findViewById(R.id.editTextWeight);

        // Add Entry button click listener
        Button buttonAddEntry = findViewById(R.id.buttonAddEntry);
        buttonAddEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addEntry();
            }
        });

        editTextGoalWeight = findViewById(R.id.editTextGoalWeight);

        Button buttonCheckGoal = findViewById(R.id.buttonCheckGoal);
        buttonCheckGoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkGoal();
            }
        });

        // Grid item click listener (optional)
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Handle grid item click if needed
            }
        });
    }

    private void addEntry() {
        String date = editTextDate.getText().toString().trim();
        String weightText = editTextWeight.getText().toString().trim();

        // Validate input
        if (date.isEmpty() || weightText.isEmpty()) {
            Toast.makeText(this, "Please enter date and weight", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double weight = Double.parseDouble(weightText);

            // Add entry to database
            dataSource.addWeightEntry(date, weight);

            // Refresh GridView with updated data
            adapter.changeCursor(dataSource.getAllWeightEntries());

            // Clear input fields
            editTextDate.setText("");
            editTextWeight.setText("");

            Toast.makeText(this, "Entry added successfully", Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            // Handle parsing error
            Toast.makeText(this, "Invalid weight format", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dataSource.close();
    }

    private void checkGoal() {
        String goalWeightStr = editTextGoalWeight.getText().toString().trim();
        if (goalWeightStr.isEmpty()) {
            Toast.makeText(this, "Please enter goal weight", Toast.LENGTH_SHORT).show();
            return;
        }

        double goalWeight = Double.parseDouble(goalWeightStr);

        if (dataSource.getMostRecentWeight() <= goalWeight) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                sendSMS("Congratulations! You have reached your goal weight.");
            } else {
                requestSMSPermission();
            }
        } else {
            Toast.makeText(this, "You haven't reached your goal weight yet.", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendSMS(String message) {
        String phoneNumber = getStoredPhoneNumber();
        if (phoneNumber != null) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(this, "SMS sent successfully", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        } else {
            Toast.makeText(this, "Phone number not found", Toast.LENGTH_SHORT).show();
        }
    }

    private void requestSMSPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSMS("Congratulations! You have reached your goal weight.");
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private String getStoredPhoneNumber() {
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        return sharedPreferences.getString("phoneNumber", null);
    }
}
