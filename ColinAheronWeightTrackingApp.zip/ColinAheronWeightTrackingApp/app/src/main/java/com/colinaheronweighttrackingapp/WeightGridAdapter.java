package com.colinaheronweighttrackingapp;
import static android.app.PendingIntent.getActivity;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

public class WeightGridAdapter extends CursorAdapter {

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        // Inflate the grid item layout
        return LayoutInflater.from(context).inflate(R.layout.grid_item_weight, parent, false);
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        // Retrieve data from cursor
        final int entryId = cursor.getInt(cursor.getColumnIndexOrThrow(WeightDBHelper.COLUMN_ID));
        String date = cursor.getString(cursor.getColumnIndexOrThrow(WeightDBHelper.COLUMN_DATE));
        double weight = cursor.getDouble(cursor.getColumnIndexOrThrow(WeightDBHelper.COLUMN_WEIGHT));

        // Populate grid item views with data
        TextView textViewDate = view.findViewById(R.id.textViewDate);
        TextView textViewWeight = view.findViewById(R.id.textViewWeight);
        Button buttonDelete = view.findViewById(R.id.buttonDelete);

        textViewDate.setText("Date:" + date);
        textViewWeight.setText("Weight: " + String.valueOf(weight));

        // Set click listener for delete button
        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Delete the corresponding entry from the database
                deleteEntry(entryId, v);
            }
        });
    }
    private WeightDataSource dataSource; // Declare dataSource as a class variable
    public WeightGridAdapter(Context context, Cursor cursor, WeightDataSource dataSource) {
        super(context, cursor, 0);
        this.dataSource = dataSource; // Initialize dataSource with the provided WeightDataSource object
    }

    private void deleteEntry(int entryId, View view) {
        try {
            // Delete the entry from the database
            dataSource.deleteWeightEntry(entryId);
            // Refresh the GridView with updated data after deletion
            changeCursor(dataSource.getAllWeightEntries());
        } catch (Exception e) {
            // Handle any exceptions that occur during deletion

            e.printStackTrace();

            // Show a toast message to indicate the deletion failure
            Toast.makeText(view.getContext(), "Failed to delete entry", Toast.LENGTH_SHORT).show();
        }
    }


}