package com.colinaheronweighttrackingapp;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class WeightDataSource {

    private SQLiteDatabase database;
    private WeightDBHelper dbHelper;

    public WeightDataSource(DashboardActivity context) {
        dbHelper = new WeightDBHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    // Method to add a new weight entry to the database
    public void addWeightEntry(String date, double weight) {
        ContentValues values = new ContentValues();
        values.put(WeightDBHelper.COLUMN_DATE, date);
        values.put(WeightDBHelper.COLUMN_WEIGHT, weight);

        database.insert(WeightDBHelper.TABLE_WEIGHT, null, values);
    }

    // Method to retrieve all weight entries from the database
    public Cursor getAllWeightEntries() {
        return database.query(WeightDBHelper.TABLE_WEIGHT, null, null, null, null, null, null);
    }

    // Method to delete all weight entries from the database
    public void deleteAllWeightEntries() {
        database.delete(WeightDBHelper.TABLE_WEIGHT, null, null);
    }
    // Method to delete a weight entry from the database
    public void deleteWeightEntry(int entryId) {
        database.delete(WeightDBHelper.TABLE_WEIGHT, WeightDBHelper.COLUMN_ID + " = ?", new String[]{String.valueOf(entryId)});
    }
    // Method to retrieve the most recent weight entry from the database
    public double getMostRecentWeight() {
        double weight = 0.0;
        Cursor cursor = database.rawQuery("SELECT " + WeightDBHelper.COLUMN_WEIGHT + " FROM " + WeightDBHelper.TABLE_WEIGHT + " ORDER BY " + WeightDBHelper.COLUMN_DATE + " DESC LIMIT 1", null);
        if (cursor != null && cursor.moveToFirst()) {
            weight = cursor.getDouble(0);
            cursor.close();
        }
        return weight;
    }

}
